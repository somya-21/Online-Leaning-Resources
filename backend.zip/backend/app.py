from flask import Flask, jsonify, request
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Configure SQLite database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///learning_resources.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Resource Model
class Resource(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    link = db.Column(db.String(500), nullable=False)
    category = db.Column(db.String(100), nullable=False)
    resource_type = db.Column(db.String(50), nullable=False)  # 'free' or 'paid'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'link': self.link,
            'category': self.category,
            'resource_type': self.resource_type,
            'created_at': self.created_at.isoformat()
        }

# Create all database tables
with app.app_context():
    db.create_all()

@app.route('/api/resources', methods=['GET'])
def get_resources():
    category = request.args.get('category')
    resource_type = request.args.get('type')
    
    query = Resource.query
    
    if category:
        query = query.filter_by(category=category)
    if resource_type:
        query = query.filter_by(resource_type=resource_type)
        
    resources = query.all()
    return jsonify([resource.to_dict() for resource in resources])

@app.route('/api/resources', methods=['POST'])
def add_resource():
    data = request.get_json()
    
    new_resource = Resource(
        title=data['title'],
        description=data['description'],
        link=data['link'],
        category=data['category'],
        resource_type=data['resource_type']
    )
    
    db.session.add(new_resource)
    db.session.commit()
    
    return jsonify(new_resource.to_dict()), 201

@app.route('/api/categories', methods=['GET'])
def get_categories():
    categories = db.session.query(Resource.category).distinct().all()
    return jsonify([category[0] for category in categories])

if __name__ == '__main__':
    app.run(debug=True)
